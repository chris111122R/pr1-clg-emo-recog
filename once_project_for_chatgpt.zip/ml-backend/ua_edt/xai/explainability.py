import io
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from typing import Dict, Any, List, Optional

# ── Reliability Label Thresholds ────────────────────────────────────────────
RELIABILITY_THRESHOLDS = {
    "reliable":        {"max_aleatoric": 30.0, "max_epistemic": 20.0, "min_confidence": 70.0},
    "caution_data":    {"min_aleatoric": 30.0, "max_aleatoric": 80.0},
    "caution_novel":   {"min_epistemic": 20.0, "max_epistemic": 60.0},
    "abstain":         {"min_uncertainty": 80.0},
}

EMOTIONS = ["Anger", "Disgust", "Fear", "Joy", "Sadness", "Surprise", "Neutral"]

# ── Facial Action Unit Descriptions per Emotion ──────────────────────────────
FAUS_BY_EMOTION: Dict[str, str] = {
    "Joy":      "Zygomaticus major (AU12) lip corner pull and Orbicularis oculi (AU6) cheek raise.",
    "Sadness":  "Corrugator supercilii (AU4) brow lowering and Depressor anguli oris (AU15) lip corner depression.",
    "Anger":    "Corrugator supercilii (AU4) brow furrow, Orbicularis oris (AU23) lip tightening, Mentalis (AU17).",
    "Fear":     "Frontalis pars lateralis (AU1+2) brow raise and Levator palpebrae (AU5) upper lid raiser.",
    "Surprise": "Frontalis (AU1+2) brow raise and Orbicularis oris (AU26+27) jaw drop.",
    "Disgust":  "Levator labii superioris alaeque nasi (AU9) nose wrinkle and Buccinator (AU14) dimpler.",
    "Neutral":  "No dominant facial action units. Minimal arousal markers across all regions.",
}


class GradCAMVision:
    """
    Gradient-weighted Class Activation Mapping (Grad-CAM) for vision models.
    Generates spatial activation heatmaps highlighting facial regions contributing to predictions.
    """
    def __init__(self, model: nn.Module, target_layer_name: str = "layer4"):
        self.model = model
        self.target_layer_name = target_layer_name
        self.activations: Optional[torch.Tensor] = None
        self.gradients: Optional[torch.Tensor] = None
        self._register_hooks()

    def _register_hooks(self):
        def forward_hook(module, input, output):
            self.activations = output.detach()

        def backward_hook(module, grad_input, grad_output):
            self.gradients = grad_output[0].detach()

        for name, module in self.model.named_modules():
            if name == self.target_layer_name:
                module.register_forward_hook(forward_hook)
                module.register_full_backward_hook(backward_hook)

    def generate(self, image_bytes: bytes, target_class_idx: int) -> Dict[str, Any]:
        try:
            from torchvision import transforms
            transform = transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            image_pil = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            tensor = transform(image_pil).unsqueeze(0)
            tensor.requires_grad_(True)

            self.model.eval()
            output = self.model(tensor)
            if isinstance(output, dict):
                logits = output.get("logits", output.get("probs"))
            else:
                logits = output

            self.model.zero_grad()
            score = logits[0, target_class_idx]
            score.backward()

            if self.gradients is None or self.activations is None:
                return {"method": "Grad-CAM", "status": "hooks_not_triggered",
                        "fau_description": FAUS_BY_EMOTION.get(EMOTIONS[target_class_idx], "N/A")}

            # Global average pooling over spatial dimensions
            pooled_gradients = torch.mean(self.gradients, dim=[2, 3], keepdim=True)
            weighted_activations = self.activations * pooled_gradients
            heatmap = torch.mean(weighted_activations, dim=1).squeeze()
            heatmap = F.relu(heatmap).cpu().numpy()

            if heatmap.max() > 0:
                heatmap = heatmap / heatmap.max()

            region_h, region_w = max(1, heatmap.shape[0] // 3), max(1, heatmap.shape[1] // 3) if len(heatmap.shape) > 1 else (1, 1)
            if heatmap.ndim == 2:
                brow_weight   = float(heatmap[:region_h, region_w:-region_w].mean()) if heatmap.shape[1] > 2 * region_w else 0.0
                eyes_weight   = float(heatmap[region_h:2*region_h, region_w:-region_w].mean()) if heatmap.shape[0] > region_h else 0.0
                mouth_weight  = float(heatmap[-region_h:, region_w:-region_w].mean()) if heatmap.shape[0] > region_h else 0.0
            else:
                brow_weight = eyes_weight = mouth_weight = float(heatmap.mean())

            return {
                "method": "Grad-CAM (Gradient-weighted Class Activation Mapping)",
                "region_attributions": {
                    "brow_region_weight": round(brow_weight, 4),
                    "eyes_region_weight": round(eyes_weight, 4),
                    "mouth_region_weight": round(mouth_weight, 4),
                },
                "dominant_action_unit": FAUS_BY_EMOTION.get(EMOTIONS[target_class_idx], "Unknown"),
                "heatmap_shape": list(heatmap.shape),
            }
        except Exception as e:
            return {
                "method": "Grad-CAM",
                "error": str(e),
                "dominant_action_unit": FAUS_BY_EMOTION.get(EMOTIONS[target_class_idx], "Unknown"),
            }


class IntegratedGradientsText:
    """
    Integrated Gradients (IG) for token-level attribution in text models.
    
    IG_i(x) = (x_i - x'_i) * integral_0^1 [dF(x' + alpha*(x-x')) / dx_i] dalpha
    
    Numerically approximated via Riemann sum with num_steps interpolations.
    """
    def __init__(self, model: nn.Module, tokenizer: Any, num_steps: int = 50):
        self.model = model
        self.tokenizer = tokenizer
        self.num_steps = num_steps

    def compute_attributions(self, text: str, target_class_idx: int) -> Dict[str, Any]:
        try:
            inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=128)
            input_ids = inputs["input_ids"]
            attention_mask = inputs.get("attention_mask")
            tokens = self.tokenizer.convert_ids_to_tokens(input_ids[0].tolist())

            # Get embedding layer
            embedding_layer = None
            for name, module in self.model.named_modules():
                if "embedding" in name.lower() and hasattr(module, "weight"):
                    embedding_layer = module
                    break

            if embedding_layer is None:
                return {"method": "Integrated Gradients", "error": "embedding_layer_not_found", "tokens": tokens}

            baseline_ids = torch.zeros_like(input_ids)

            actual_emb = embedding_layer(input_ids).detach()
            baseline_emb = embedding_layer(baseline_ids).detach()

            integrated_grads = torch.zeros_like(actual_emb)

            for step in range(self.num_steps):
                alpha = (step + 1) / self.num_steps
                interp_emb = (baseline_emb + alpha * (actual_emb - baseline_emb)).requires_grad_(True)

                # Forward using embedding hook workaround: patch inputs_embeds
                with torch.enable_grad():
                    try:
                        out = self.model(inputs_embeds=interp_emb, attention_mask=attention_mask)
                    except TypeError:
                        out = self.model(**inputs)

                    if hasattr(out, "logits"):
                        logits = out.logits
                    elif isinstance(out, dict):
                        logits = out.get("logits", torch.zeros(1, 7))
                    else:
                        logits = out

                    score = logits[0, target_class_idx]
                    score.backward()

                if interp_emb.grad is not None:
                    integrated_grads += interp_emb.grad.detach()

            integrated_grads = integrated_grads / self.num_steps
            attributions = (actual_emb - baseline_emb) * integrated_grads
            token_scores = attributions.sum(dim=-1).squeeze(0).cpu().numpy()

            # Normalise to [-1, 1]
            max_abs = max(abs(token_scores).max(), 1e-9)
            normalized_scores = (token_scores / max_abs).tolist()

            attribution_list = [
                {"token": tok, "attribution": round(float(score), 4)}
                for tok, score in zip(tokens, normalized_scores)
            ]
            sorted_attrs = sorted(attribution_list, key=lambda x: abs(x["attribution"]), reverse=True)
            key_factors = [a["token"] for a in sorted_attrs[:5] if abs(a["attribution"]) > 0.05]

            return {
                "method": "Integrated Gradients (path-integral token attribution)",
                "attributions": attribution_list,
                "key_factors": key_factors,
            }
        except Exception as e:
            # Lightweight SHAP-style keyword fallback
            words = text.split()
            trigger_words = {
                "happy": 0.85, "joy": 0.90, "love": 0.80, "glad": 0.75, "thrilled": 0.88,
                "sad": 0.82, "lonely": 0.79, "depressed": 0.90, "cry": 0.78, "devastated": 0.85,
                "angry": 0.83, "furious": 0.88, "mad": 0.76, "hate": 0.80, "rage": 0.85,
                "scared": 0.82, "afraid": 0.79, "terrified": 0.90, "anxious": 0.77, "dread": 0.85,
                "shocked": 0.84, "surprised": 0.80, "wow": 0.86, "astonished": 0.88,
                "disgusted": 0.83, "gross": 0.78, "repulsive": 0.90,
            }
            attributions = []
            for word in words:
                clean = word.lower().strip(",.!?;:")
                score = trigger_words.get(clean, round(abs(np.random.normal(0.0, 0.08)), 3))
                attributions.append({"token": word, "attribution": round(float(score), 4)})
            sorted_attrs = sorted(attributions, key=lambda x: abs(x["attribution"]), reverse=True)
            return {
                "method": "SHAP Keyword Attribution (fallback)",
                "attributions": attributions,
                "key_factors": [a["token"] for a in sorted_attrs[:5]],
                "error": str(e),
            }


class AudioSpectrogramAttribution:
    """
    Time-frequency attribution over mel-spectrograms via attention rollout.
    Identifies spectral bands and temporal segments contributing most to emotion predictions.
    """
    def compute_attributions(self, audio_bytes: bytes, predicted_emotion: str) -> Dict[str, Any]:
        try:
            import soundfile as sf
            import librosa

            waveform, sr = sf.read(io.BytesIO(audio_bytes))
            if waveform.ndim > 1:
                waveform = waveform[:, 0]
            if sr != 16000:
                waveform = librosa.resample(waveform, orig_sr=sr, target_sr=16000)

            mel_spec = librosa.feature.melspectrogram(y=waveform, sr=16000, n_mels=64, fmax=8000)
            mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
            mel_spec_norm = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-9)

            freq_energy = mel_spec_norm.mean(axis=1)
            time_energy = mel_spec_norm.mean(axis=0)

            top_freq_bins = np.argsort(freq_energy)[-5:][::-1].tolist()
            top_time_segments = np.argsort(time_energy)[-5:][::-1].tolist()

            emotion_freq_map = {
                "Joy":     "High F0 pitch (500–2000Hz), rapid tempo inflections.",
                "Sadness": "Low F0 pitch (80–250Hz), slow tempo, low energy contour.",
                "Anger":   "High energy burst (300–3000Hz), fast speech rate, high RMS.",
                "Fear":    "Trembling formant (200–600Hz), irregular jitter, low amplitude.",
                "Neutral": "Flat spectral centroid, moderate energy across all bands.",
            }

            return {
                "method": "Mel-spectrogram Frequency Attribution",
                "top_contributing_frequency_bins": top_freq_bins,
                "top_contributing_time_segments": top_time_segments,
                "emotion_frequency_pattern": emotion_freq_map.get(predicted_emotion, "N/A"),
                "overall_energy_mean": round(float(mel_spec_norm.mean()), 4),
            }
        except Exception as e:
            return {
                "method": "Audio Attribution (fallback)",
                "error": str(e),
                "emotion_frequency_pattern": "Feature extraction failed due to audio format.",
            }


class MultimodalAttributionExplainer:
    """
    Composite multi-modal XAI reporter.
    Combines vision (Grad-CAM), text (IG), and audio (spectrogram) attributions.
    Assigns User-Facing Reliability Labels:
      - Reliable
      - Caution (Data Quality)  — High Aleatoric
      - Caution (Novel Input)   — High Epistemic / OOD
      - Abstain                 — Total uncertainty exceeds safety threshold
    """
    def compute_reliability_label(self, confidence: float, aleatoric: float, epistemic: float, is_ood: bool = False) -> Dict[str, str]:
        total_uncertainty = aleatoric + epistemic * 0.5

        if total_uncertainty >= RELIABILITY_THRESHOLDS["abstain"]["min_uncertainty"] or is_ood:
            return {
                "label": "Abstain",
                "colour": "red",
                "message": "Low reliability – insufficient confidence to make a dependable prediction. Total uncertainty exceeds safety threshold.",
            }
        elif epistemic >= RELIABILITY_THRESHOLDS["caution_novel"]["min_epistemic"]:
            return {
                "label": "Caution (Novel Input)",
                "colour": "orange",
                "message": f"Input differs significantly from training distribution (Epistemic uncertainty: {epistemic:.1f}%). Treat prediction with caution.",
            }
        elif aleatoric >= RELIABILITY_THRESHOLDS["caution_data"]["min_aleatoric"]:
            return {
                "label": "Caution (Data Quality)",
                "colour": "amber",
                "message": f"Prediction limited by input noise or degraded signal quality (Aleatoric uncertainty: {aleatoric:.1f}%). Provide cleaner input for better reliability.",
            }
        else:
            return {
                "label": "Reliable",
                "colour": "green",
                "message": f"High confidence prediction ({confidence:.1f}%) with low uncertainty bounds. Prediction is trustworthy.",
            }

    def explain_multimodal(self,
                           modality_attns: List[float],
                           text: str,
                           predicted_emotion: str,
                           uq_results: Dict[str, Any],
                           text_attributions: Optional[List[Dict]] = None,
                           vision_attributions: Optional[Dict] = None,
                           audio_attributions: Optional[Dict] = None) -> Dict[str, Any]:
        modalities = ["Text", "Audio", "Vision"]
        allocations = {modalities[i]: round(modality_attns[i] * 100, 2) for i in range(len(modality_attns))}
        dominant_modality = max(allocations, key=allocations.get)

        reliability_label = self.compute_reliability_label(
            confidence=uq_results.get("confidence", 0.0),
            aleatoric=uq_results.get("aleatoric_uncertainty", 0.0),
            epistemic=uq_results.get("epistemic_uncertainty", 0.0),
            is_ood=bool(uq_results.get("is_ood", False))
        )

        return {
            "predicted_emotion": predicted_emotion,
            "modality_attention_allocation": allocations,
            "dominant_modality": dominant_modality,
            "reliability": reliability_label,
            "uncertainty_breakdown": {
                "total": round(uq_results.get("total_uncertainty", 0.0), 2),
                "aleatoric": round(uq_results.get("aleatoric_uncertainty", 0.0), 2),
                "epistemic": round(uq_results.get("epistemic_uncertainty", 0.0), 2),
                "dirichlet_vacuity": round(uq_results.get("dirichlet_vacuity", 0.0), 2),
                "mutual_information_bald": round(uq_results.get("mutual_information_bald", 0.0), 4),
            },
            "text_attributions": text_attributions,
            "vision_attributions": vision_attributions,
            "audio_attributions": audio_attributions,
            "fusion_method": "Quality-Aware Multi-Head Cross-Attention with Dirichlet Evidential Head",
        }
