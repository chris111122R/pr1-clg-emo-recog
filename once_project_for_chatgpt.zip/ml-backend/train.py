import os
import argparse
import random
import numpy as np
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler
from torch.cuda.amp import autocast, GradScaler
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
from sklearn.calibration import calibration_curve
import optuna
import pandas as pd
# import wandb
# import mlflow
from typing import Dict, Any

from ua_edt.models.ua_edt_model import UAEDTMultimodalModel
from ua_edt.models.heads import EvidentialLoss

from services.text_pipeline import tokenizer as default_text_tokenizer
from services.audio_pipeline import processor as default_audio_processor
# from services.image_pipeline import transform as default_image_transform

EMOTIONS = ["Joy", "Sadness", "Anger", "Fear", "Surprise", "Disgust", "Neutral"]

from ua_edt.data import IEMOCAPDataset, CMUMOSEIDataset, AffectNetDataset, get_class_balanced_sampler

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def get_scheduler(optimizer, warmup_steps, total_steps):
    from torch.optim.lr_scheduler import LambdaLR
    import math
    def lr_lambda(current_step):
        if current_step < warmup_steps:
            return float(current_step) / float(max(1, warmup_steps))
        progress = float(current_step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return 0.5 * (1.0 + math.cos(math.pi * progress))
    return LambdaLR(optimizer, lr_lambda)

def calibrate_energy_threshold(model, val_loader, device):
    """
    Step 7: Calibrate the energy OOD threshold data-driven via AUROC.
    Runs validation on a mix of clean and synthetically corrupted samples
    to find the energy threshold that maximizes separation (TPR - FPR).
    """
    model.eval()
    energy_scores = []
    labels_ood = [] # 0 for clean (in-distribution), 1 for corrupted (OOD)
    
    with torch.no_grad():
        for batch in val_loader:
            text_emb, audio_emb, vision_emb, labels = [b.to(device) for b in batch]
            
            # Clean passes (In-distribution, label 0)
            out_clean = model(text_emb, audio_emb, vision_emb)
            energy_scores.extend(out_clean["energy"].tolist())
            labels_ood.extend([0] * labels.size(0))
            
            # Corrupted passes (OOD, label 1)
            bad_vision = vision_emb * 0.1 + torch.randn_like(vision_emb) * 2.0
            bad_text = text_emb * 0.1 + torch.randn_like(text_emb) * 2.0
            bad_audio = audio_emb * 0.1 + torch.randn_like(audio_emb) * 2.0
            
            out_ood = model(bad_text, bad_audio, bad_vision)
            energy_scores.extend(out_ood["energy"].tolist())
            labels_ood.extend([1] * labels.size(0))
            
    fpr, tpr, thresholds = roc_curve(labels_ood, energy_scores)
    roc_auc = auc(fpr, tpr)
    
    # Find threshold maximizing Youden's J statistic (TPR - FPR)
    optimal_idx = np.argmax(tpr - fpr)
    optimal_threshold = thresholds[optimal_idx]
    
    print(f"Energy OOD Calibration -> AUROC: {roc_auc:.4f}, Optimal Threshold: {optimal_threshold:.4f}")
    
    # Update the model's threshold dynamically
    model.ood_detector.ood_threshold = optimal_threshold
    return optimal_threshold, roc_auc

def train_and_evaluate(
    model: nn.Module,
    train_dataset,
    val_dataset,
    lr: float,
    weight_decay: float,
    dropout: float,
    epochs: int,
    batch_size: int = 16,
    use_amp: bool = True,
    grad_accum_steps: int = 1,
    patience: int = 3,
    resume_from_checkpoint: str = None,
    is_distributed: bool = False,
    local_rank: int = 0,
    outlier_exposure: bool = True
) -> float:
    device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    if is_distributed:
        model = nn.parallel.DistributedDataParallel(model, device_ids=[local_rank], output_device=local_rank)
        train_sampler = DistributedSampler(train_dataset)
    else:
        train_sampler = get_class_balanced_sampler(train_dataset.labels)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, sampler=train_sampler)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # Calculate Inverse Frequency Class Weights
    from collections import Counter
    label_counts = Counter(train_dataset.labels)
    total_samples = sum(label_counts.values())
    weights = [total_samples / (len(EMOTIONS) * max(1, label_counts.get(i, 1))) for i in range(len(EMOTIONS))]
    class_weights = torch.tensor(weights, dtype=torch.float32).to(device)

    criterion = EvidentialLoss(num_classes=len(EMOTIONS), class_weights=class_weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    
    total_steps = len(train_loader) * epochs // grad_accum_steps
    warmup_steps = int(total_steps * 0.1)
    scheduler = get_scheduler(optimizer, warmup_steps, total_steps)
    scaler = GradScaler() if use_amp else None
    
    start_epoch = 1
    best_val_loss = float("inf")
    patience_counter = 0
    history = {"train_loss": [], "val_loss": [], "val_acc": []}

    if resume_from_checkpoint and os.path.exists(resume_from_checkpoint):
        checkpoint = torch.load(resume_from_checkpoint, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        if use_amp and checkpoint["scaler_state_dict"]: 
            scaler.load_state_dict(checkpoint["scaler_state_dict"])
        start_epoch = checkpoint["epoch"] + 1
        best_val_loss = checkpoint["best_loss"]
        if local_rank == 0:
            print(f"Resumed from epoch {start_epoch-1}")

    global_step = (start_epoch - 1) * len(train_loader)

    for epoch in range(start_epoch, epochs + 1):
        if is_distributed:
            train_sampler.set_epoch(epoch)
            
        model.train()
        train_loss = 0.0
        optimizer.zero_grad()
        
        for idx, batch in enumerate(train_loader):
            global_step += 1
            text_emb, audio_emb, vision_emb, labels = [b.to(device) for b in batch]
            # Step 6: Outlier Exposure Training
            is_ood = outlier_exposure and random.random() < 0.15
            if is_ood:
                vision_emb = vision_emb * 0.1 + torch.randn_like(vision_emb) * 2.0
                text_emb = text_emb * 0.1 + torch.randn_like(text_emb) * 2.0
                audio_emb = audio_emb * 0.1 + torch.randn_like(audio_emb) * 2.0
                # Flat Dirichlet target forces KL divergence to penalize any non-zero evidence
                labels_one_hot = torch.zeros(labels.size(0), len(EMOTIONS), device=device)
            else:
                labels_one_hot = torch.nn.functional.one_hot(labels, num_classes=len(EMOTIONS)).float()

            if use_amp:
                with autocast():
                    outputs = model(text_emb, audio_emb, vision_emb)
                    loss = criterion(outputs, labels_one_hot, global_step=global_step)
                scaler.scale(loss).backward()
            else:
                outputs = model(text_emb, audio_emb, vision_emb)
                loss = criterion(outputs, labels_one_hot, global_step=global_step)
                loss.backward()
                
            if (idx + 1) % grad_accum_steps == 0:
                if use_amp:
                    scaler.unscale_(optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                
            train_loss += loss.item()
            
        train_loss /= len(train_loader)
        
        model.eval()
        val_loss, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for batch in val_loader:
                text_emb, audio_emb, vision_emb, labels = [b.to(device) for b in batch]
                labels_one_hot = torch.nn.functional.one_hot(labels, num_classes=len(EMOTIONS)).float()
                
                outputs = model(text_emb, audio_emb, vision_emb)
                loss = criterion(outputs, labels_one_hot, global_step=global_step)
                val_loss += loss.item()
                
                _, predicted = torch.max(outputs["probs"], 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                
        val_loss /= len(val_loader)
        val_acc = (correct / total) * 100
        
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)
        
        if local_rank == 0:
            print(f"Epoch {epoch} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%")
            
            # MLOps Logging
            metrics = {"train_loss": train_loss, "val_loss": val_loss, "val_acc": val_acc, "epoch": epoch}
            if args.use_wandb: wandb.log(metrics, step=epoch)
            if args.use_mlflow: mlflow.log_metrics(metrics, step=epoch)
            
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                os.makedirs("./checkpoints", exist_ok=True)
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "scheduler_state_dict": scheduler.state_dict(),
                    "scaler_state_dict": scaler.state_dict() if use_amp else None,
                    "best_loss": best_val_loss,
                    "metrics": {"accuracy": val_acc}
                }, "./checkpoints/best_model.pt")
            else:
                patience_counter += 1
                
        if patience_counter >= patience:
            if local_rank == 0: print("Early stopping triggered.")
            break
            
    if local_rank == 0:
        print("Calibrating Energy OOD Threshold...")
        optimal_threshold, roc_auc = calibrate_energy_threshold(model, val_loader, device)
        # Store calibrated threshold in a way that can be saved if we rewrite the checkpoint
        if hasattr(model, 'module'):
            model.module.ood_detector.ood_threshold = optimal_threshold
        else:
            model.ood_detector.ood_threshold = optimal_threshold

    return best_val_loss, history

def run_hyperparameter_optimization(train_dataset, val_dataset, trials: int, epochs: int) -> Dict[str, Any]:
    def objective(trial):
        lr = trial.suggest_float("lr", 1e-5, 1e-3, log=True)
        weight_decay = trial.suggest_float("weight_decay", 1e-6, 1e-2, log=True)
        dropout = trial.suggest_float("dropout", 0.1, 0.5)
        batch_size = trial.suggest_categorical("batch_size", [8, 16, 32])
        lora_rank = trial.suggest_categorical("lora_rank", [4, 8, 16])
        
        model = UAEDTMultimodalModel(
            text_dim=768, audio_dim=768, vision_dim=768,
            projection_dim=256, num_classes=len(EMOTIONS)
        )
        
        val_loss, _ = train_and_evaluate(
            model=model,
            train_dataset=train_dataset,
            val_dataset=val_dataset,
            lr=lr,
            weight_decay=weight_decay,
            dropout=dropout,
            epochs=epochs,
            batch_size=batch_size,
            use_amp=True,
            grad_accum_steps=2,
            patience=2
        )
        return val_loss

    study = optuna.create_study(direction="minimize")
    study.optimize(objective, n_trials=trials)
    
    # Export CSV of trials
    df = study.trials_dataframe()
    df.to_csv("optuna_trials.csv", index=False)
    print("Exported optuna_trials.csv")
    
    return study.best_params

def generate_evaluation_artifacts(model: nn.Module, test_loader: DataLoader, output_dir: str = "./checkpoints"):
    os.makedirs(output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()
    
    all_preds, all_targets, all_probs = [], [], []
    
    with torch.no_grad():
        for batch in test_loader:
            text_emb, audio_emb, vision_emb, labels = [b.to(device) for b in batch]
            outputs = model(text_emb, audio_emb, vision_emb)
            probs = outputs["probs"]
            _, predicted = torch.max(probs, 1)
            
            all_preds.extend(predicted.cpu().numpy())
            all_targets.extend(labels.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
            
    all_preds = np.array(all_preds)
    all_targets = np.array(all_targets)
    all_probs = np.array(all_probs)
    
    cm = confusion_matrix(all_targets, all_preds, labels=list(range(len(EMOTIONS))))
    plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title("Confusion Matrix")
    plt.colorbar()
    tick_marks = np.arange(len(EMOTIONS))
    plt.xticks(tick_marks, EMOTIONS, rotation=45)
    plt.yticks(tick_marks, EMOTIONS)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "confusion_matrix.png"))
    plt.close()
    
    report = classification_report(all_targets, all_preds, labels=list(range(len(EMOTIONS))), target_names=EMOTIONS, zero_division=0)
    with open(os.path.join(output_dir, "evaluation_report.txt"), "w") as f:
        f.write(report)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--lite", action="store_true")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--trials", type=int, default=3)
    parser.add_argument("--resume", type=str, default=None)
    parser.add_argument("--local_rank", type=int, default=-1)
    parser.add_argument("--use_wandb", action="store_true")
    parser.add_argument("--use_mlflow", action="store_true")
    args = parser.parse_args()
    
    if args.use_wandb and (args.local_rank == -1 or args.local_rank == 0):
        wandb.init(project="ua-edt-multimodal", config=vars(args))
    if args.use_mlflow and (args.local_rank == -1 or args.local_rank == 0):
        mlflow.set_experiment("ua-edt-multimodal")
        mlflow.start_run()
        
    set_seed(42)
    
    is_distributed = False
    local_rank = 0
    if args.local_rank != -1 or "LOCAL_RANK" in os.environ:
        is_distributed = True
        local_rank = int(os.environ.get("LOCAL_RANK", args.local_rank))
        dist.init_process_group(backend="nccl" if torch.cuda.is_available() else "gloo")
        if torch.cuda.is_available():
            torch.cuda.set_device(local_rank)
        
    if local_rank == 0: print("Initializing dataset...")
    num_train = 50 if args.lite else 200
    num_val = 20 if args.lite else 50
    
    train_dataset = CMUMOSEIDataset(is_training=True)
    val_dataset = CMUMOSEIDataset(is_training=False)
    test_dataset = CMUMOSEIDataset(is_training=False)
    
    epochs = 2 if args.lite else args.epochs
    trials = 2 if args.lite else args.trials
    
    if local_rank == 0:
        print(f"Skipping Optuna...")
        best_params = {"lr": 1e-4, "weight_decay": 1e-4, "dropout": 0.3, "batch_size": 16, "lora_rank": 8}
        print(f"Optimal parameters: {best_params}")
    else:
        best_params = {"lr": 1e-4, "weight_decay": 1e-4, "dropout": 0.3, "batch_size": 16, "lora_rank": 8}
        
    if is_distributed: dist.barrier()
    
    best_model = UAEDTMultimodalModel(
        text_dim=768, audio_dim=768, vision_dim=768,
        projection_dim=256, num_classes=len(EMOTIONS)
    )
    
    test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)
    
    best_loss, history = train_and_evaluate(
        model=best_model,
        train_dataset=train_dataset,
        val_dataset=val_dataset,
        lr=best_params["lr"],
        weight_decay=best_params["weight_decay"],
        dropout=best_params["dropout"],
        epochs=epochs,
        batch_size=best_params["batch_size"],
        use_amp=True,
        grad_accum_steps=2,
        patience=3,
        resume_from_checkpoint=args.resume,
        is_distributed=is_distributed,
        local_rank=local_rank
    )
    
    if local_rank == 0:
        plt.figure(figsize=(10, 4))
        plt.subplot(1, 2, 1)
        plt.plot(history["train_loss"], label="Train Loss")
        plt.plot(history["val_loss"], label="Val Loss")
        plt.legend()
        plt.subplot(1, 2, 2)
        plt.plot(history["val_acc"], label="Val Accuracy")
        plt.legend()
        plt.savefig("./checkpoints/loss_accuracy_curves.png")
        plt.close()
        
        generate_evaluation_artifacts(best_model, test_loader)
        print("Exporting models to ONNX and TorchScript...")
        
        class ONNXWrapper(nn.Module):
            def __init__(self, m): super().__init__(); self.m = m
            def forward(self, t, a, v):
                out = self.m(t, a, v)
                return out["logits"], out["probs"], out["vacuity"], out["modality_attn"]
                
        device = next(best_model.parameters()).device
        dummy_t = torch.zeros(1, 768, device=device)
        dummy_a = torch.zeros(1, 768, device=device)
        dummy_v = torch.zeros(1, 768, device=device)
        
        wrapper = ONNXWrapper(best_model)
        wrapper.eval()
        
        torch.onnx.export(
            wrapper, (dummy_t, dummy_a, dummy_v),
            "./checkpoints/best_model.onnx",
            export_params=True, opset_version=14, do_constant_folding=True,
            input_names=['text_emb', 'audio_emb', 'vision_emb'],
            output_names=['logits', 'probs', 'vacuity', 'modality_attn'],
            dynamic_axes={'text_emb': {0: 'batch_size'}, 'audio_emb': {0: 'batch_size'}, 'vision_emb': {0: 'batch_size'}}
        )
        
        traced = torch.jit.trace(wrapper, (dummy_t, dummy_a, dummy_v))
        traced.save("./checkpoints/best_model_traced.pt")
        
        if args.use_wandb: wandb.finish()
        if args.use_mlflow: mlflow.end_run()
        
        print("Training finished successfully. Saved all artifacts to ./checkpoints/")
