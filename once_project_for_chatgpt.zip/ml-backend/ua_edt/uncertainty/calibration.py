import torch
import torch.nn as nn
import numpy as np
from scipy.optimize import minimize

class TemperatureScaler(nn.Module):
    """
    Temperature Scaling for post-hoc confidence calibration.
    Learns a single scalar T optimized on a validation set via NLL minimization (L-BFGS).
    Calibrated probabilities: P_cal(y|x) = Softmax(logits / T)
    """
    def __init__(self):
        super().__init__()
        self.temperature = nn.Parameter(torch.ones(1) * 1.5)

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits / self.temperature.clamp(min=0.05)

    def calibrate(self, logits_val: torch.Tensor, labels_val: torch.Tensor) -> float:
        """
        Optimizes temperature using L-BFGS on validation set logits.
        Returns optimal temperature value.
        """
        self.eval()
        nll_criterion = nn.CrossEntropyLoss()

        def eval_temp(t):
            t_tensor = torch.tensor([t[0]], dtype=torch.float32)
            scaled = logits_val / t_tensor.clamp(min=0.05)
            loss = nll_criterion(scaled, labels_val).item()
            return loss

        result = minimize(eval_temp, [1.5], method="L-BFGS-B", bounds=[(0.05, 10.0)],
                          options={"maxiter": 100, "ftol": 1e-7})
        optimal_t = float(result.x[0])
        self.temperature.data = torch.tensor([optimal_t])
        return optimal_t


class CalibrationMetrics:
    """
    Computes calibration metrics on a set of model predictions.
    Implements:
      - Expected Calibration Error (ECE) with M=15 equal-width bins
      - Maximum Calibration Error (MCE)
      - Negative Log-Likelihood (NLL)
      - Brier Score
    """
    def __init__(self, num_bins: int = 15):
        self.num_bins = num_bins

    def compute_ece(self, confidences: np.ndarray, accuracies: np.ndarray) -> float:
        """
        ECE = sum_{b=1}^{M} (|B_b| / n) * |acc(B_b) - conf(B_b)|
        """
        n = len(confidences)
        bins = np.linspace(0.0, 1.0, self.num_bins + 1)
        ece = 0.0
        for i in range(self.num_bins):
            lo, hi = bins[i], bins[i + 1]
            in_bin = (confidences > lo) & (confidences <= hi)
            if in_bin.sum() == 0:
                continue
            bin_conf = confidences[in_bin].mean()
            bin_acc = accuracies[in_bin].mean()
            bin_weight = in_bin.sum() / n
            ece += bin_weight * abs(bin_acc - bin_conf)
        return float(ece)

    def compute_mce(self, confidences: np.ndarray, accuracies: np.ndarray) -> float:
        """MCE = max_{b} |acc(B_b) - conf(B_b)|"""
        bins = np.linspace(0.0, 1.0, self.num_bins + 1)
        mce = 0.0
        for i in range(self.num_bins):
            lo, hi = bins[i], bins[i + 1]
            in_bin = (confidences > lo) & (confidences <= hi)
            if in_bin.sum() == 0:
                continue
            bin_conf = confidences[in_bin].mean()
            bin_acc = accuracies[in_bin].mean()
            mce = max(mce, abs(bin_acc - bin_conf))
        return float(mce)

    def compute_nll(self, probs: np.ndarray, labels: np.ndarray) -> float:
        """NLL = -mean(log(P(y_true | x)))"""
        n = len(labels)
        log_probs = np.log(probs[np.arange(n), labels] + 1e-9)
        return float(-np.mean(log_probs))

    def compute_brier_score(self, probs: np.ndarray, labels: np.ndarray) -> float:
        """Brier Score = (1/n) * sum ||P(y|x) - y_one_hot||^2"""
        n = len(labels)
        num_classes = probs.shape[1]
        y_one_hot = np.eye(num_classes)[labels]
        return float(np.mean(np.sum((probs - y_one_hot) ** 2, axis=1)))

    def compute_all(self, probs: np.ndarray, labels: np.ndarray) -> dict:
        confidences = probs.max(axis=1)
        predictions = probs.argmax(axis=1)
        accuracies = (predictions == labels).astype(float)
        return {
            "ece": round(self.compute_ece(confidences, accuracies), 4),
            "mce": round(self.compute_mce(confidences, accuracies), 4),
            "nll": round(self.compute_nll(probs, labels), 4),
            "brier_score": round(self.compute_brier_score(probs, labels), 4),
            "accuracy": round(float(accuracies.mean()), 4),
        }
