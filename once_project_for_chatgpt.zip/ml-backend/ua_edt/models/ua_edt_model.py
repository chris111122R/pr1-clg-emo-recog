import torch
import torch.nn as nn
from typing import Dict, Any, Optional

from .fusion import QualityAwareGatedFusion, EnergyOODDetector
from .heads import EvidentialClassificationHead
from .backbones import ModalityBackboneRegistry

class UAEDTMultimodalModel(nn.Module):
    """
    Complete Research-Grade UA-EDT Multimodal Model.
    
    Integrates:
    - Projection & Multi-Head Cross-Attention Gated Fusion (Quality-Aware).
    - Evidential Classification Head (Dirichlet distribution parameters).
    - Energy-Based Out-Of-Distribution (OOD) Detection.
    """
    def __init__(self, 
                 text_dim: int = 768, 
                 audio_dim: int = 768, 
                 vision_dim: int = 768, 
                 projection_dim: int = 256, 
                 num_classes: int = 7):
        super().__init__()
        self.num_classes = num_classes
        self.projection_dim = projection_dim

        # Quality-Aware Dynamic Gated Fusion Layer
        self.fusion = QualityAwareGatedFusion(
            text_dim=text_dim,
            audio_dim=audio_dim,
            vision_dim=vision_dim,
            projection_dim=projection_dim
        )

        # Evidential Head (Subjective Logic / Dirichlet parameterization)
        self.evidential_head = EvidentialClassificationHead(
            in_features=projection_dim,
            num_classes=num_classes,
            dropout_rate=0.3
        )

        # Energy OOD Detector
        self.ood_detector = EnergyOODDetector(temperature=1.0)

    def forward(self, 
                text_emb: Optional[torch.Tensor] = None, 
                audio_emb: Optional[torch.Tensor] = None, 
                vision_emb: Optional[torch.Tensor] = None,
                q_scores: Optional[Dict[str, float]] = None) -> dict:
        
        # 1. Fuse embeddings with quality gating g(q_m) and cross-attention
        fusion_res = self.fusion(
            text_emb=text_emb,
            audio_emb=audio_emb,
            vision_emb=vision_emb,
            q_scores=q_scores
        )

        fused_vec = fusion_res["fused_representation"]

        # 2. Forward pass through Evidential Head
        evidential_res = self.evidential_head(fused_vec)

        # 3. Energy OOD detection
        ood_res = self.ood_detector.is_ood(evidential_res["logits"])

        # 4. Fuse Vacuity and Energy into Final Confidence
        # Expected probability of the predicted class
        max_prob, _ = torch.max(evidential_res["probs"], dim=-1)
        
        # Soft blend: penalize confidence by vacuity
        fused_confidence = max_prob * (1.0 - evidential_res["vacuity"])
        
        # Hard gate: if OOD, force confidence to extremely low (or zero)
        is_ood_mask = torch.tensor(ood_res["is_ood"], device=fused_confidence.device, dtype=torch.float32)
        fused_confidence = fused_confidence * (1.0 - is_ood_mask)

        return {
            "fused_representation": fused_vec,
            "logits": evidential_res["logits"],
            "evidence": evidential_res["evidence"],
            "alpha": evidential_res["alpha"],
            "S": evidential_res["S"],
            "probs": evidential_res["probs"],
            "vacuity": evidential_res["vacuity"],
            "modality_attn": fusion_res["modality_attn"],
            "quality_gates": fusion_res["quality_gates"],
            "energy": ood_res["energy"],
            "is_ood": ood_res["is_ood"],
            "final_confidence": fused_confidence
        }

class UAEDTEndToEndModel(nn.Module):
    """
    End-to-End Multimodal Model combining the Resource-Aware Backbone Registry 
    with the Quality-Aware Gated Fusion and Evidential Classification Head.
    
    Accepts raw inputs (text sequences, audio waveforms, image tensors) and processes
    them completely through feature extraction and fusion.
    """
    def __init__(self, num_classes: int = 7):
        super().__init__()
        self.registry = ModalityBackboneRegistry.build(proj_dim=256)
        
        vision_dim = self.registry.config.vision.hidden_size
        audio_dim = self.registry.config.audio.hidden_size
        text_dim = self.registry.config.text.hidden_size
        
        self.multimodal_head = UAEDTMultimodalModel(
            text_dim=text_dim,
            audio_dim=audio_dim,
            vision_dim=vision_dim,
            projection_dim=256,
            num_classes=num_classes
        )

    def forward(self, 
                text_inputs: Optional[Dict[str, torch.Tensor]] = None,
                audio_inputs: Optional[Dict[str, torch.Tensor]] = None,
                vision_inputs: Optional[Dict[str, torch.Tensor]] = None,
                q_scores: Optional[Dict[str, float]] = None) -> dict:
        
        text_emb = self.registry.extract_raw_text(text_inputs) if text_inputs else None
        audio_emb = self.registry.extract_raw_audio(audio_inputs) if audio_inputs else None
        vision_emb = self.registry.extract_raw_vision(vision_inputs) if vision_inputs else None
        
        return self.multimodal_head(text_emb, audio_emb, vision_emb, q_scores)
