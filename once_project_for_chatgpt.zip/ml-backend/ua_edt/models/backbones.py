"""
ua_edt.models.backbones
========================
Resource-Aware Modality Backbone Registry for multimodal emotion recognition.

Implements lazy-loading of pre-trained transformer encoders with automatic
hardware-aware model selection:

  ┌─────────────┬──────────────────────────────────┬──────────────────────────────┐
  │ Modality    │ High-Memory (≥ 24 GB VRAM / CPU)  │ Low-Memory (< 24 GB VRAM)   │
  ├─────────────┼──────────────────────────────────┼──────────────────────────────┤
  │ Vision      │ openai/clip-vit-large-patch14    │ openai/clip-vit-base-patch32 │
  │ Audio       │ facebook/wav2vec2-large-robust   │ facebook/wav2vec2-base-960h  │
  │ Text        │ microsoft/deberta-v3-large       │ microsoft/deberta-v3-small   │
  └─────────────┴──────────────────────────────────┴──────────────────────────────┘

Each encoder is wrapped in `ModalityEncoder`, which:
  1. Loads the pre-trained model on demand (lazy initialisation).
  2. Extracts CLS / mean-pool feature embeddings.
  3. Projects to the unified fusion space via `ModalityProjector`.
  4. Normalises the projection to the unit hypersphere for contrastive learning:
       z_m = g_m(h_m) / ‖g_m(h_m)‖₂

VRAM Detection
--------------
  - Uses `torch.cuda.get_device_properties(0).total_memory` when CUDA is available.
  - Falls back to CPU-mode (uses low-memory backbone configs).
  - 24 GB threshold corresponds to A100/A40/RTX 3090/4090 VRAM class.

References
----------
  - Radford, A. et al., "Learning Transferable Visual Models From Natural Language
    Supervision" (CLIP), ICML 2021.
  - Baevski, A. et al., "wav2vec 2.0: A Framework for Self-Supervised Learning of
    Speech Representations", NeurIPS 2020.
  - He, P. et al., "DeBERTa: Decoding-enhanced BERT with Disentangled Attention",
    ICLR 2021.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)

# ── VRAM Threshold ───────────────────────────────────────────────────────────
_HIGH_VRAM_BYTES: int = 24 * 1024 ** 3  # 24 GB in bytes


@dataclass
class BackboneConfig:
    """Configuration for a single modality backbone."""
    checkpoint: str
    hidden_size: int           # Output embedding dimension
    pooling: str = "mean"      # 'mean' | 'cls' | 'last'
    layer_norm: bool = True


@dataclass
class ResourceAwareConfig:
    """
    Resource-aware backbone selection configuration.

    Attributes
    ----------
    device : str       — Detected compute device ('cuda:0' or 'cpu').
    vram_gb : float    — Available VRAM in gigabytes (0.0 for CPU).
    is_high_memory : bool — True if VRAM ≥ 24 GB or on CPU with sufficient RAM.
    vision  : BackboneConfig
    audio   : BackboneConfig
    text    : BackboneConfig
    """
    device: str = "cpu"
    vram_gb: float = 0.0
    is_high_memory: bool = False
    vision: BackboneConfig = field(default_factory=lambda: BackboneConfig(
        checkpoint="google/vit-base-patch16-224", hidden_size=768, pooling="cls"
    ))
    audio: BackboneConfig = field(default_factory=lambda: BackboneConfig(
        checkpoint="facebook/wav2vec2-base-960h", hidden_size=768, pooling="mean"
    ))
    text: BackboneConfig = field(default_factory=lambda: BackboneConfig(
        checkpoint="microsoft/deberta-v3-small", hidden_size=768, pooling="cls"
    ))

    @classmethod
    def detect(cls) -> "ResourceAwareConfig":
        """
        Detect available compute resources and return the appropriate config.

        Selects high-memory backbones when ≥ 24 GB VRAM is available;
        falls back to base-size backbones otherwise.
        """
        config = cls()

        if torch.cuda.is_available():
            try:
                props = torch.cuda.get_device_properties(0)
                total_vram = props.total_memory
                vram_gb = total_vram / (1024 ** 3)
                config.device = "cuda:0"
                config.vram_gb = round(vram_gb, 2)
                config.is_high_memory = total_vram >= _HIGH_VRAM_BYTES
                logger.info(
                    f"CUDA device: {props.name} | VRAM: {vram_gb:.1f} GB | "
                    f"High-memory mode: {config.is_high_memory}"
                )
            except Exception as e:
                logger.warning(f"CUDA property detection failed: {e}. Using CPU.")
                config.device = "cpu"
                config.is_high_memory = False
        else:
            logger.info("CUDA not available. Using CPU with low-memory backbones.")

        if config.is_high_memory:
            config.vision = BackboneConfig(
                checkpoint="google/vit-large-patch16-224",
                hidden_size=1024,
                pooling="cls",
            )
            config.audio = BackboneConfig(
                checkpoint="facebook/hubert-large-ls960-ft",
                hidden_size=1024,
                pooling="mean",
            )
            config.text = BackboneConfig(
                checkpoint="roberta-large",
                hidden_size=1024,
                pooling="cls",
            )
        else:
            config.vision = BackboneConfig(
                checkpoint="google/vit-base-patch16-224",
                hidden_size=768,
                pooling="cls",
            )
            config.audio = BackboneConfig(
                checkpoint="facebook/wav2vec2-base-960h",
                hidden_size=768,
                pooling="mean",
            )
            config.text = BackboneConfig(
                checkpoint="microsoft/deberta-v3-small",
                hidden_size=768,
                pooling="cls",
            )

        return config


class ModalityProjector(nn.Module):
    """
    Projects a modality-specific embedding into the shared d-dimensional
    contrastive representation space and L2-normalises the result.

    z_m = g_m(h_m) / ‖g_m(h_m)‖₂

    where g_m is a 2-layer MLP with LayerNorm:
      Linear(in_dim → hidden_dim) → LayerNorm → GELU → Linear(hidden_dim → out_dim)

    Parameters
    ----------
    in_dim      : int — Input embedding dimensionality (backbone hidden size).
    out_dim     : int — Contrastive projection dimension d (default 256).
    hidden_dim  : int — MLP hidden dimension (default 512).
    normalize   : bool — Apply L2 normalisation to output (required for SupCon).
    """

    def __init__(
        self,
        in_dim: int,
        out_dim: int = 256,
        hidden_dim: int = 512,
        normalize: bool = True,
    ) -> None:
        super().__init__()
        self.normalize = normalize
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        h : torch.Tensor, shape (B, in_dim)

        Returns
        -------
        z : torch.Tensor, shape (B, out_dim)
            L2-normalised contrastive projection (if normalize=True).
        """
        z = self.mlp(h)
        if self.normalize:
            z = F.normalize(z, p=2, dim=-1)
        return z


class ModalityEncoder(nn.Module):
    """
    Unified modality-specific encoder wrapper.

    Wraps a pre-trained transformer backbone and exposes a consistent
    `extract_features(inputs)` interface regardless of backbone family.

    Architecture
    ------------
    Backbone (CLIP-ViT / Wav2Vec2 / DeBERTa) → Pool → ModalityProjector → z_m

    Parameters
    ----------
    config      : BackboneConfig — Backbone checkpoint and pooling strategy.
    proj_dim    : int            — Contrastive projection dimension.
    freeze_backbone : bool       — If True, backbone parameters are frozen
                                   (used during initial training stages).
    """

    def __init__(
        self,
        config: BackboneConfig,
        proj_dim: int = 256,
        freeze_backbone: bool = True,
    ) -> None:
        super().__init__()
        self.config = config
        self.proj_dim = proj_dim
        self._backbone: Optional[nn.Module] = None  # Lazy-loaded
        self.projector = ModalityProjector(
            in_dim=config.hidden_size,
            out_dim=proj_dim,
            normalize=True,
        )
        self._freeze_backbone = freeze_backbone

    def _load_backbone(self) -> nn.Module:
        """
        Lazy-loads the backbone model from HuggingFace Hub with LoRA integration and Gradient Checkpointing.
        """
        from transformers import AutoModel, ViTModel, Wav2Vec2Model, HubertModel
        try:
            from peft import get_peft_model, LoraConfig
        except ImportError:
            LoraConfig = None

        checkpoint = self.config.checkpoint
        logger.info(f"Loading backbone: {checkpoint}")

        try:
            if "vit" in checkpoint.lower():
                model = ViTModel.from_pretrained(checkpoint)
            elif "wav2vec2" in checkpoint.lower():
                model = Wav2Vec2Model.from_pretrained(checkpoint)
            elif "hubert" in checkpoint.lower():
                model = HubertModel.from_pretrained(checkpoint)
            else:
                model = AutoModel.from_pretrained(checkpoint)

            # Enable gradient checkpointing to save memory
            if hasattr(model, "gradient_checkpointing_enable"):
                model.gradient_checkpointing_enable()

            if LoraConfig is not None and not self._freeze_backbone:
                peft_config = LoraConfig(
                    inference_mode=False, r=8, lora_alpha=32, lora_dropout=0.1
                )
                model = get_peft_model(model, peft_config)
                logger.info(f"LoRA applied to {checkpoint}.")
            elif self._freeze_backbone:
                for param in model.parameters():
                    param.requires_grad = False
                logger.info(f"Backbone {checkpoint} frozen (freeze_backbone=True).")

        except Exception as e:
            logger.error(
                f"Failed to load backbone '{checkpoint}': {e}. "
                "ModalityEncoder will return zero embeddings until backbone is available."
            )
            model = None  # type: ignore[assignment]

        return model

    def get_backbone(self) -> Optional[nn.Module]:
        """Returns the backbone, loading it on first call."""
        if self._backbone is None:
            self._backbone = self._load_backbone()
        return self._backbone

    def _pool_output(self, backbone_output, input_shape: Tuple[int, ...]) -> torch.Tensor:
        """
        Extracts a fixed-size embedding from variable-length backbone outputs.

        Pooling strategies:
          'cls'  — Uses the first token (CLS) output: last_hidden_state[:, 0, :]
          'mean' — Mean over sequence length (masking PAD tokens if mask available).
          'last' — Last token's hidden state.
        """
        # Extract last hidden state
        if hasattr(backbone_output, "last_hidden_state"):
            hidden = backbone_output.last_hidden_state  # (B, T, D)
        elif hasattr(backbone_output, "pooler_output") and backbone_output.pooler_output is not None:
            return backbone_output.pooler_output         # (B, D) — already pooled
        elif isinstance(backbone_output, torch.Tensor):
            hidden = backbone_output
        else:
            hidden = backbone_output[0]

        if self.config.pooling == "cls":
            return hidden[:, 0, :]          # CLS token
        elif self.config.pooling == "mean":
            return hidden.mean(dim=1)       # Mean pool over sequence
        elif self.config.pooling == "last":
            return hidden[:, -1, :]         # Last token
        else:
            return hidden.mean(dim=1)

    def forward(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Extract and project modality features.

        Parameters
        ----------
        inputs : dict — Tokenized/preprocessed inputs for the backbone.
                        For vision: {'pixel_values': Tensor (B, C, H, W)}
                        For audio:  {'input_values': Tensor (B, T), optional 'attention_mask'}
                        For text:   {'input_ids': Tensor (B, L), 'attention_mask': Tensor (B, L)}

        Returns
        -------
        z_m : torch.Tensor, shape (B, proj_dim) — L2-normalised projection.
              Returns zero vector if backbone is unavailable.
        """
        backbone = self.get_backbone()

        if backbone is None:
            # Fallback: return zero embedding when backbone is not available
            batch_size = next(iter(inputs.values())).shape[0]
            device = next(iter(inputs.values())).device
            return torch.zeros(batch_size, self.proj_dim, device=device)

        device = next(backbone.parameters()).device
        # Move inputs to backbone device
        inputs_on_device = {k: v.to(device) for k, v in inputs.items()}

        with torch.set_grad_enabled(not self._freeze_backbone):
            backbone_out = backbone(**inputs_on_device)

        h = self._pool_output(backbone_out, input_shape=())
        z = self.projector(h)
        return z

    def extract_raw_features(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Extract raw, unprojected modality features (h_m).
        """
        backbone = self.get_backbone()

        if backbone is None:
            # Fallback: return zero embedding when backbone is not available
            batch_size = next(iter(inputs.values())).shape[0]
            device = next(iter(inputs.values())).device
            return torch.zeros(batch_size, self.config.hidden_size, device=device)

        device = next(backbone.parameters()).device
        # Move inputs to backbone device
        inputs_on_device = {k: v.to(device) for k, v in inputs.items()}

        with torch.set_grad_enabled(not self._freeze_backbone):
            backbone_out = backbone(**inputs_on_device)

        h = self._pool_output(backbone_out, input_shape=())
        return h

    def unfreeze_top_n_layers(self, n: int = 4) -> None:
        """
        Progressively unfreezes the top n transformer layers of the backbone.
        Used during discriminative layer unfreezing training schedule.

        Parameters
        ----------
        n : int — Number of top transformer layers to unfreeze.
        """
        backbone = self.get_backbone()
        if backbone is None:
            return

        # Find all transformer layer blocks (works for ViT, Wav2Vec2, DeBERTa)
        layer_blocks: List[nn.Module] = []
        for name, module in backbone.named_modules():
            if any(
                key in name.lower()
                for key in ["encoder.layer.", "encoder.layers.", "blocks.", "layers."]
            ):
                # Collect top-level numbered blocks
                parts = name.split(".")
                for i, part in enumerate(parts):
                    if part.isdigit():
                        layer_blocks.append(module)
                        break

        # Deduplicate while preserving order
        seen = set()
        unique_blocks = []
        for b in layer_blocks:
            bid = id(b)
            if bid not in seen:
                seen.add(bid)
                unique_blocks.append(b)

        # Unfreeze last n unique blocks
        top_n = unique_blocks[-n:] if len(unique_blocks) >= n else unique_blocks
        unfrozen_params = 0
        for block in top_n:
            for param in block.parameters():
                param.requires_grad = True
                unfrozen_params += param.numel()

        logger.info(
            f"Unfroze top {len(top_n)} transformer layers "
            f"({unfrozen_params:,} parameters unlocked)."
        )
        self._freeze_backbone = False  # Mark as partially unfrozen


class ModalityBackboneRegistry:
    """
    Registry managing all three modality encoders with resource-aware configuration.

    Usage
    -----
    registry = ModalityBackboneRegistry.build()
    vision_emb = registry.encode_vision(pixel_values_dict)
    audio_emb  = registry.encode_audio(audio_dict)
    text_emb   = registry.encode_text(text_dict)

    All encoders are lazy-loaded on first use. The registry exposes
    discriminative unfreezing methods for the training pipeline.
    """

    def __init__(self, config: ResourceAwareConfig, proj_dim: int = 256) -> None:
        self.config = config
        self.proj_dim = proj_dim

        self.vision_encoder = ModalityEncoder(
            config.vision, proj_dim=proj_dim, freeze_backbone=True
        )
        self.audio_encoder = ModalityEncoder(
            config.audio, proj_dim=proj_dim, freeze_backbone=True
        )
        self.text_encoder = ModalityEncoder(
            config.text, proj_dim=proj_dim, freeze_backbone=True
        )

    @classmethod
    def build(cls, proj_dim: int = 256) -> "ModalityBackboneRegistry":
        """
        Build the registry with automatic hardware-aware backbone selection.

        Parameters
        ----------
        proj_dim : int — Contrastive projection dimension (default 256).

        Returns
        -------
        ModalityBackboneRegistry instance ready for use.
        """
        config = ResourceAwareConfig.detect()
        return cls(config, proj_dim=proj_dim)

    def encode_vision(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract vision features → z_v ∈ ℝ^{proj_dim} (L2-normalised)."""
        return self.vision_encoder(inputs)

    def encode_audio(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract audio features → z_a ∈ ℝ^{proj_dim} (L2-normalised)."""
        return self.audio_encoder(inputs)

    def encode_text(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract text features → z_t ∈ ℝ^{proj_dim} (L2-normalised)."""
        return self.text_encoder(inputs)

    def extract_raw_vision(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract unprojected vision features (h_v)."""
        return self.vision_encoder.extract_raw_features(inputs)

    def extract_raw_audio(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract unprojected audio features (h_a)."""
        return self.audio_encoder.extract_raw_features(inputs)

    def extract_raw_text(self, inputs: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Extract unprojected text features (h_t)."""
        return self.text_encoder.extract_raw_features(inputs)

    def unfreeze_schedule(self, epoch: int, total_epochs: int, n_layers: int = 4) -> None:
        """
        Apply the discriminative layer unfreezing schedule.

        Schedule (per specification):
          - Epochs 0-4         : All backbones frozen (only heads trained).
          - Epoch 5            : Unfreeze top n_layers of each backbone.
          - Epoch 10+          : Full fine-tuning (all parameters active).

        Parameters
        ----------
        epoch       : int — Current epoch index (0-based).
        total_epochs: int — Total number of training epochs.
        n_layers    : int — Number of top backbone layers to unfreeze at epoch 5.
        """
        if epoch == 5:
            logger.info(f"Epoch {epoch}: Unfreezing top {n_layers} layers of all backbones.")
            for encoder in [self.vision_encoder, self.audio_encoder, self.text_encoder]:
                encoder.unfreeze_top_n_layers(n=n_layers)
        elif epoch >= 10:
            logger.info(f"Epoch {epoch}: Full fine-tuning — unfreezing all backbone layers.")
            for encoder in [self.vision_encoder, self.audio_encoder, self.text_encoder]:
                backbone = encoder.get_backbone()
                if backbone is not None:
                    for param in backbone.parameters():
                        param.requires_grad = True

    def get_device(self) -> str:
        """Returns the primary compute device string."""
        return self.config.device

    def summary(self) -> Dict:
        """Returns a configuration summary dict for logging."""
        return {
            "device": self.config.device,
            "vram_gb": self.config.vram_gb,
            "is_high_memory": self.config.is_high_memory,
            "vision_backbone": self.config.vision.checkpoint,
            "audio_backbone": self.config.audio.checkpoint,
            "text_backbone": self.config.text.checkpoint,
            "projection_dim": self.proj_dim,
        }
